#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "6.1.0"
#endif
